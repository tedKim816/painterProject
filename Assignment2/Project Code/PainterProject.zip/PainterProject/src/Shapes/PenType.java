package Shapes;

public enum PenType {
    None,
    Point,
    Line,
    Circle,
    Ellipse,
    Rectangle,
    Poly
}
